package com.ahmed.catoslauncher

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import kotlinx.coroutines.*
import java.text.SimpleDateFormat
import java.util.*

val Pink = Color(0xFFFF2E93)
val Purple = Color(0xFF8A2BE2)
val Ink = Color(0xFF12071F)

class AppItem(val label: String, val pkg: String, val cls: String, val icon: ImageBitmap)
class DockItem(val intent: Intent, val icon: ImageBitmap)

class MainActivity : ComponentActivity() {
    private val tick = mutableIntStateOf(0)
    private val home = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Pink, surface = Ink)) {
                Launcher(this, tick.intValue, home.intValue)
            }
        }
    }

    override fun onResume() { super.onResume(); tick.intValue++ }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.hasCategory(Intent.CATEGORY_HOME)) home.intValue++
    }

    /** Real background blur of the wallpaper (Android 12+). Silently ignored where unsupported. */
    fun setBlur(r: Int) {
        if (Build.VERSION.SDK_INT < 31) return
        runOnUiThread {
            try {
                window.setBackgroundDrawable(ColorDrawable(if (r > 0) 0x33000000 else 0))
                window.setBackgroundBlurRadius(r)
            } catch (_: Throwable) {}
        }
    }
}

fun loadApps(ctx: Context): List<AppItem> {
    val pm = ctx.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0)
        .filter { it.activityInfo.packageName != ctx.packageName }
        .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.activityInfo.name, it.loadIcon(pm).toBitmap(128, 128).asImageBitmap()) }
        .sortedBy { it.label.lowercase() }
}

fun launch(ctx: Context, a: AppItem) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(a.pkg, a.cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED))
    } catch (_: Exception) {}
}

/** Liquid-glass look: translucent gradient fill, top gloss, bright rim light. */
fun Modifier.glass(shape: androidx.compose.ui.graphics.Shape, a: Float = 0.12f): Modifier = this
    .clip(shape)
    .background(Brush.linearGradient(listOf(Color.White.copy(a + .10f), Color.White.copy(a * .4f))))
    .drawBehind { drawRect(Brush.verticalGradient(listOf(Color.White.copy(.16f), Color.Transparent), endY = size.height * .45f)) }
    .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(.7f), Color.White.copy(.06f), Color.White.copy(.3f))), shape)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Modifier.press(onClick: () -> Unit, onLong: () -> Unit = {}): Modifier {
    val src = remember { MutableInteractionSource() }
    val down by src.collectIsPressedAsState()
    val s by animateFloatAsState(if (down) .86f else 1f, spring(0.5f, 500f), label = "press")
    return this.graphicsLayer { scaleX = s; scaleY = s }
        .combinedClickable(interactionSource = src, indication = null, onClick = onClick, onLongClick = onLong)
}

@Composable
fun AppCell(a: AppItem, modifier: Modifier, onClick: () -> Unit, onLong: () -> Unit) {
    Column(modifier.press(onClick, onLong).padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(62.dp).glass(RoundedCornerShape(20.dp)), contentAlignment = Alignment.Center) {
            Image(a.icon, null, Modifier.size(44.dp))
        }
        Spacer(Modifier.height(5.dp))
        Text(a.label, color = Color.White, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun ClockCard() {
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { now = Date(); delay(10_000) } }
    Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(32.dp)).padding(horizontal = 26.dp, vertical = 20.dp)) {
        Text("CATOS", color = Pink, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
        Text(SimpleDateFormat("HH:mm", Locale.getDefault()).format(now), color = Color.White, fontSize = 64.sp, fontWeight = FontWeight.Light)
        Text(SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(now), color = Color.White.copy(.75f), fontSize = 16.sp)
    }
}

@Composable
fun Launcher(act: MainActivity, tick: Int, homeTick: Int) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("catos", Context.MODE_PRIVATE) }
    var apps by remember { mutableStateOf(emptyList<AppItem>()) }
    var pins by remember { mutableStateOf(prefs.getStringSet("pins", emptySet())!!.toSet()) }
    LaunchedEffect(tick) { apps = withContext(Dispatchers.Default) { loadApps(ctx) } }

    val dock = remember(tick) {
        val pm = ctx.packageManager
        listOf(Intent(Intent.ACTION_DIAL), Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")), Intent(MediaStore.ACTION_IMAGE_CAPTURE))
            .mapNotNull { i ->
                pm.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)?.takeIf { it.activityInfo.packageName != "android" }
                    ?.let { DockItem(i, it.loadIcon(pm).toBitmap(128, 128).asImageBitmap()) }
            }
    }

    val p = remember { Animatable(0f) }                       // 0 = home, 1 = drawer open
    val hPx = with(LocalDensity.current) { LocalConfiguration.current.screenHeightDp.dp.toPx() }
    val drag = rememberDraggableState { d -> scope.launch { p.snapTo((p.value - d / hPx * 1.25f).coerceIn(0f, 1f)) } }
    val stop: suspend CoroutineScope.(Float) -> Unit = { v ->
        p.animateTo(when { v < -1200f -> 1f; v > 1200f -> 0f; p.value > .4f -> 1f; else -> 0f }, spring(.82f, 280f))
    }
    LaunchedEffect(homeTick) { if (homeTick > 0) p.animateTo(0f) }
    LaunchedEffect(Unit) { snapshotFlow { p.value > 0.5f }.collect { act.setBlur(if (it) 90 else 0) } }
    BackHandler { scope.launch { p.animateTo(0f) } }

    val togglePin = { k: String ->
        pins = if (k in pins) pins - k else pins + k
        prefs.edit().putStringSet("pins", pins).apply()
    }
    val open = { a: AppItem -> launch(ctx, a); scope.launch { delay(250); p.snapTo(0f) }; Unit }

    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Purple.copy(.22f), Ink.copy(.55f)))))

        // ---------- HOME ----------
        Column(
            Modifier.fillMaxSize()
                .draggable(drag, Orientation.Vertical, onDragStopped = stop)
                .graphicsLayer { alpha = 1f - p.value * .7f; val s = 1f - p.value * .06f; scaleX = s; scaleY = s }
                .windowInsetsPadding(WindowInsets.systemBars).padding(horizontal = 20.dp)
        ) {
            Spacer(Modifier.height(24.dp))
            ClockCard()
            Spacer(Modifier.height(20.dp))
            val pinned = apps.filter { it.pkg in pins }
            if (pinned.isNotEmpty()) Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(32.dp)).padding(10.dp)) {
                pinned.chunked(4).forEach { row ->
                    Row(Modifier.fillMaxWidth()) {
                        row.forEach { a -> AppCell(a, Modifier.weight(1f), { open(a) }, { togglePin(a.pkg) }) }
                        repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
            Spacer(Modifier.weight(1f))
            Row(Modifier.fillMaxWidth().glass(RoundedCornerShape(36.dp), .14f).padding(horizontal = 14.dp, vertical = 12.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                dock.forEach { d ->
                    Image(d.icon, null, Modifier.size(52.dp).press({ try { ctx.startActivity(d.intent.apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }) } catch (_: Exception) {} }))
                }
            }
            Spacer(Modifier.height(12.dp))
            Box(Modifier.align(Alignment.CenterHorizontally).glass(CircleShape).clickable { scope.launch { p.animateTo(1f) } }.padding(horizontal = 22.dp, vertical = 10.dp)) {
                Text("Swipe up  •  Long-press apps to pin", color = Color.White.copy(.8f), fontSize = 12.sp)
            }
            Spacer(Modifier.height(12.dp))
        }

        // ---------- DRAWER ----------
        if (p.value > 0f) Drawer(
            apps, pins, togglePin, open,
            Modifier.graphicsLayer { translationY = (1f - p.value) * hPx; alpha = (p.value * 2f).coerceIn(0f, 1f) },
            Modifier.draggable(drag, Orientation.Vertical, onDragStopped = stop)
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Drawer(apps: List<AppItem>, pins: Set<String>, togglePin: (String) -> Unit, onOpen: (AppItem) -> Unit, modifier: Modifier, header: Modifier) {
    val ctx = LocalContext.current
    var q by remember { mutableStateOf("") }
    var menuFor by remember { mutableStateOf<AppItem?>(null) }
    val list = remember(apps, q) { if (q.isBlank()) apps else apps.filter { it.label.contains(q.trim(), true) } }
    fun sys(i: Intent) { try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}; menuFor = null }

    Column(modifier.fillMaxSize()
        .background(Brush.verticalGradient(listOf(Ink.copy(.35f), Ink.copy(.72f))))
        .windowInsetsPadding(WindowInsets.systemBars).imePadding().padding(horizontal = 16.dp)) {
        Column(header.fillMaxWidth()) {
            Box(Modifier.align(Alignment.CenterHorizontally).padding(top = 10.dp, bottom = 12.dp).size(40.dp, 5.dp).clip(CircleShape).background(Color.White.copy(.5f)))
            BasicTextField(
                q, { q = it }, singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 16.sp), cursorBrush = SolidColor(Pink),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { list.firstOrNull()?.let(onOpen) }),
                modifier = Modifier.fillMaxWidth().glass(RoundedCornerShape(26.dp)).padding(horizontal = 18.dp, vertical = 14.dp),
                decorationBox = { inner -> Box { if (q.isEmpty()) Text("Search apps…", color = Color.White.copy(.5f)); inner() } }
            )
        }
        LazyVerticalGrid(GridCells.Fixed(4), contentPadding = PaddingValues(top = 14.dp, bottom = 24.dp)) {
            items(list, key = { it.pkg + it.cls }) { a ->
                Box(Modifier.fillMaxWidth()) {
                    AppCell(a, Modifier.fillMaxWidth(), { onOpen(a) }, { menuFor = a })
                    DropdownMenu(expanded = menuFor == a, onDismissRequest = { menuFor = null }) {
                        DropdownMenuItem(text = { Text(if (a.pkg in pins) "Unpin from home" else "Pin to home") }, onClick = { togglePin(a.pkg); menuFor = null })
                        DropdownMenuItem(text = { Text("App info") }, onClick = { sys(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}"))) })
                        DropdownMenuItem(text = { Text("Uninstall") }, onClick = { sys(Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}"))) })
                    }
                }
            }
        }
    }
}
