package com.ahmed.catoslauncher

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.*
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import kotlinx.coroutines.*
import java.text.SimpleDateFormat
import java.util.*

// ---------------------------------------------------------------- theme / settings

val Accents = listOf(Color(0xFFFF2E93), Color(0xFF8A2BE2), Color(0xFF00E5FF), Color(0xFF34D399), Color(0xFFFFB020), Color(0xFF3B82F6))
val Purple = Color(0xFF8A2BE2)
val Ink = Color(0xFF12071F)
val GameHints = listOf("minecraft", "roblox", "pubg", "freefire", "garena", "supercell", "mobilelegends", "moonton", "activision", "epicgames", "gameloft", ".game")

private fun SharedPreferences.strs(k: String): Set<String> = getStringSet(k, emptySet())?.toSet() ?: emptySet()

data class Prefs(
    val accent: Int = 0, val glass: Float = .12f, val blur: Int = 90, val dim: Float = .2f,
    val iconSize: Int = 44, val cols: Int = 4, val shape: Int = 0,
    val labels: Boolean = true, val list: Boolean = false,
    val clock: Boolean = true, val h24: Boolean = true, val date: Boolean = true,
    val dock: Boolean = true, val games: Boolean = true, val haptic: Boolean = true, val notif: Boolean = true,
    val pins: Set<String> = emptySet(), val hidden: Set<String> = emptySet(),
    val gAdd: Set<String> = emptySet(), val gRem: Set<String> = emptySet()
) {
    val color: Color get() = Accents[accent.coerceIn(0, Accents.lastIndex)]

    fun save(p: SharedPreferences) {
        p.edit().putInt("accent", accent).putFloat("glass", glass).putInt("blur", blur).putFloat("dim", dim)
            .putInt("iconSize", iconSize).putInt("cols", cols).putInt("shape", shape)
            .putBoolean("labels", labels).putBoolean("list", list).putBoolean("clock", clock)
            .putBoolean("h24", h24).putBoolean("date", date).putBoolean("dock", dock)
            .putBoolean("games", games).putBoolean("haptic", haptic).putBoolean("notif", notif)
            .putStringSet("pins", pins).putStringSet("hidden", hidden)
            .putStringSet("gAdd", gAdd).putStringSet("gRem", gRem).apply()
    }

    companion object {
        fun load(p: SharedPreferences) = Prefs(
            accent = p.getInt("accent", 0), glass = p.getFloat("glass", .12f), blur = p.getInt("blur", 90), dim = p.getFloat("dim", .2f),
            iconSize = p.getInt("iconSize", 44), cols = p.getInt("cols", 4), shape = p.getInt("shape", 0),
            labels = p.getBoolean("labels", true), list = p.getBoolean("list", false),
            clock = p.getBoolean("clock", true), h24 = p.getBoolean("h24", true), date = p.getBoolean("date", true),
            dock = p.getBoolean("dock", true), games = p.getBoolean("games", true),
            haptic = p.getBoolean("haptic", true), notif = p.getBoolean("notif", true),
            pins = p.strs("pins"), hidden = p.strs("hidden"), gAdd = p.strs("gAdd"), gRem = p.strs("gRem")
        )
    }
}

val LocalCfg = compositionLocalOf { Prefs() }

class AppItem(val label: String, val pkg: String, val cls: String, val icon: ImageBitmap, val auto: Boolean)
class DockItem(val intent: Intent, val icon: ImageBitmap)

fun isGame(a: AppItem, c: Prefs) = a.pkg !in c.gRem && (a.auto || a.pkg in c.gAdd)
fun Set<String>.toggle(k: String): Set<String> = if (k in this) this - k else this + k
fun tileShape(c: Prefs): Shape = RoundedCornerShape(when (c.shape) { 0 -> 30; 1 -> 50; else -> 10 })

// ---------------------------------------------------------------- activity

class MainActivity : ComponentActivity() {
    private val tick = mutableIntStateOf(0)
    private val home = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Accents[0], surface = Ink)) {
                Launcher(this, tick.intValue, home.intValue)
            }
        }
    }

    override fun onResume() { super.onResume(); tick.intValue++ }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.hasCategory(Intent.CATEGORY_HOME)) home.intValue++
    }

    /** Real background blur of the wallpaper (Android 12+). Silently ignored where unsupported. */
    fun setBlur(r: Int) {
        if (Build.VERSION.SDK_INT < 31) return
        runOnUiThread {
            try {
                window.setBackgroundDrawable(ColorDrawable(if (r > 0) 0x33000000 else 0))
                window.setBackgroundBlurRadius(r)
            } catch (_: Throwable) {}
        }
    }

    /** Pull down the notification shade (works on most phones). */
    fun expandNotifications() {
        try {
            val sb = getSystemService("statusbar")
            Class.forName("android.app.StatusBarManager").getMethod("expandNotificationsPanel").invoke(sb)
        } catch (_: Throwable) {}
    }
}

@Suppress("DEPRECATION")
fun loadApps(ctx: Context): List<AppItem> {
    val pm = ctx.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0)
        .filter { it.activityInfo.packageName != ctx.packageName }
        .map {
            val ai = it.activityInfo.applicationInfo
            val pkg = it.activityInfo.packageName
            val g = ai.category == ApplicationInfo.CATEGORY_GAME ||
                (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0 ||
                GameHints.any { h -> pkg.contains(h, true) }
            AppItem(it.loadLabel(pm).toString(), pkg, it.activityInfo.name, it.loadIcon(pm).toBitmap(128, 128).asImageBitmap(), g)
        }
        .sortedBy { it.label.lowercase() }
}

fun launch(ctx: Context, a: AppItem) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(a.pkg, a.cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED))
    } catch (_: Exception) {}
}

// ---------------------------------------------------------------- small building blocks

/** Liquid-glass look: translucent gradient fill, top gloss, bright rim light. */
@Composable
fun Modifier.glass(shape: Shape, extra: Float = 0f): Modifier {
    val a = LocalCfg.current.glass + extra
    return this
        .clip(shape)
        .background(Brush.linearGradient(listOf(Color.White.copy(a + .10f), Color.White.copy(a * .4f))))
        .drawBehind { drawRect(Brush.verticalGradient(listOf(Color.White.copy(.16f), Color.Transparent), endY = size.height * .45f)) }
        .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(.7f), Color.White.copy(.06f), Color.White.copy(.3f))), shape)
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Modifier.press(onClick: () -> Unit, onLong: (() -> Unit)? = null): Modifier {
    val src = remember { MutableInteractionSource() }
    val down by src.collectIsPressedAsState()
    val hf = LocalHapticFeedback.current
    val haptic = LocalCfg.current.haptic
    val s by animateFloatAsState(if (down) .86f else 1f, spring(0.5f, 500f), label = "press")
    val longCb: (() -> Unit)? = onLong?.let { f -> { if (haptic) hf.performHapticFeedback(HapticFeedbackType.LongPress); f() } }
    return this.graphicsLayer { scaleX = s; scaleY = s }
        .combinedClickable(interactionSource = src, indication = null, onClick = onClick, onLongClick = longCb)
}

@Composable
fun IconTile(a: AppItem) {
    val cfg = LocalCfg.current
    Box(Modifier.size((cfg.iconSize + 18).dp).glass(tileShape(cfg)), contentAlignment = Alignment.Center) {
        Image(a.icon, null, Modifier.size(cfg.iconSize.dp))
    }
}

@Composable
fun AppCell(a: AppItem, modifier: Modifier, onClick: () -> Unit, onLong: (() -> Unit)? = null) {
    val cfg = LocalCfg.current
    Column(modifier.press(onClick, onLong).padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        IconTile(a)
        if (cfg.labels) {
            Spacer(Modifier.height(5.dp))
            Text(a.label, color = Color.White, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun ClockCard() {
    val cfg = LocalCfg.current
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { now = Date(); delay(10_000) } }
    Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(32.dp)).padding(horizontal = 26.dp, vertical = 20.dp)) {
        Text("CATOS", color = cfg.color, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
        Text(SimpleDateFormat(if (cfg.h24) "HH:mm" else "h:mm", Locale.getDefault()).format(now), color = Color.White, fontSize = 64.sp, fontWeight = FontWeight.Light)
        if (cfg.date) Text(SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(now), color = Color.White.copy(.75f), fontSize = 16.sp)
    }
}

// ---------------------------------------------------------------- launcher root

@Composable
fun Launcher(act: MainActivity, tick: Int, homeTick: Int) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("catos", Context.MODE_PRIVATE) }
    var cfg by remember { mutableStateOf(Prefs.load(prefs)) }
    val upd: ((Prefs) -> Prefs) -> Unit = { f -> cfg = f(cfg); cfg.save(prefs) }
    var apps by remember { mutableStateOf(emptyList<AppItem>()) }
    var showSettings by remember { mutableStateOf(false) }
    LaunchedEffect(tick) { apps = withContext(Dispatchers.Default) { loadApps(ctx) } }

    val dock = remember(tick) {
        val pm = ctx.packageManager
        listOf(Intent(Intent.ACTION_DIAL), Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")), Intent(MediaStore.ACTION_IMAGE_CAPTURE))
            .mapNotNull { i ->
                pm.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)?.takeIf { it.activityInfo.packageName != "android" }
                    ?.let { DockItem(i, it.loadIcon(pm).toBitmap(128, 128).asImageBitmap()) }
            }
    }

    val p = remember { Animatable(0f) }                       // 0 = home, 1 = drawer open
    var startP by remember { mutableFloatStateOf(0f) }
    val hPx = with(LocalDensity.current) { LocalConfiguration.current.screenHeightDp.dp.toPx() }
    val drag = rememberDraggableState { d -> scope.launch { p.snapTo((p.value - d / hPx * 1.25f).coerceIn(0f, 1f)) } }
    val stop: suspend CoroutineScope.(Float) -> Unit = { v ->
        if (cfg.notif && startP < .05f && p.value < .05f && v > 1400f) act.expandNotifications()
        else p.animateTo(when { v < -1200f -> 1f; v > 1200f -> 0f; p.value > .4f -> 1f; else -> 0f }, spring(.82f, 280f))
    }
    val dragMod = Modifier.draggable(drag, Orientation.Vertical, onDragStarted = { _ -> startP = p.value }, onDragStopped = stop)

    LaunchedEffect(homeTick) { if (homeTick > 0) { showSettings = false; p.animateTo(0f) } }
    LaunchedEffect(cfg.blur) { snapshotFlow { p.value > 0.5f || showSettings }.collect { act.setBlur(if (it) cfg.blur else 0) } }
    BackHandler { scope.launch { p.animateTo(0f) } }
    BackHandler(enabled = showSettings) { showSettings = false }

    val open = { a: AppItem -> launch(ctx, a); scope.launch { delay(250); p.snapTo(0f) }; Unit }
    val pinned = apps.filter { it.pkg in cfg.pins && it.pkg !in cfg.hidden }.take(cfg.cols * 2)
    val games = apps.filter { it.pkg !in cfg.hidden && isGame(it, cfg) }

    CompositionLocalProvider(LocalCfg provides cfg) {
        Box(Modifier.fillMaxSize()) {
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Purple.copy(.22f), Ink.copy(.55f)))))
            Box(Modifier.fillMaxSize().background(Color.Black.copy(cfg.dim)))

            // ---------- HOME ----------
            Column(
                Modifier.fillMaxSize().then(dragMod)
                    .graphicsLayer { alpha = 1f - p.value * .7f; val s = 1f - p.value * .06f; scaleX = s; scaleY = s }
                    .windowInsetsPadding(WindowInsets.systemBars).padding(horizontal = 20.dp)
            ) {
                Spacer(Modifier.height(24.dp))
                Column(Modifier.weight(1f).clipToBounds()) {
                    if (cfg.clock) { ClockCard(); Spacer(Modifier.height(20.dp)) }
                    if (pinned.isNotEmpty()) Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(32.dp)).padding(10.dp)) {
                        pinned.chunked(cfg.cols).forEach { row ->
                            Row(Modifier.fillMaxWidth()) {
                                row.forEach { a -> AppCell(a, Modifier.weight(1f), { open(a) }, { upd { it.copy(pins = it.pins - a.pkg) } }) }
                                repeat(cfg.cols - row.size) { Spacer(Modifier.weight(1f)) }
                            }
                        }
                    }
                    if (cfg.games && games.isNotEmpty()) {
                        Spacer(Modifier.height(14.dp))
                        Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(32.dp)).padding(top = 14.dp, bottom = 4.dp)) {
                            Text("GAMES", color = cfg.color, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp, modifier = Modifier.padding(start = 22.dp))
                            LazyRow(contentPadding = PaddingValues(horizontal = 10.dp)) {
                                items(games, key = { it.pkg + it.cls }) { a -> AppCell(a, Modifier.width(78.dp), { open(a) }) }
                            }
                        }
                    }
                }
                if (cfg.dock && dock.isNotEmpty()) {
                    Row(Modifier.fillMaxWidth().glass(RoundedCornerShape(36.dp), .02f).padding(horizontal = 14.dp, vertical = 12.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                        dock.forEach { d ->
                            Image(d.icon, null, Modifier.size(52.dp).press({ try { ctx.startActivity(d.intent.apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }) } catch (_: Exception) {} }))
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.align(Alignment.CenterHorizontally), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.glass(CircleShape).clickable { scope.launch { p.animateTo(1f) } }.padding(horizontal = 22.dp, vertical = 10.dp)) {
                        Text("Swipe up for apps", color = Color.White.copy(.8f), fontSize = 12.sp)
                    }
                    Box(Modifier.size(40.dp).glass(CircleShape).clickable { showSettings = true }, contentAlignment = Alignment.Center) {
                        Text("⚙", color = Color.White, fontSize = 18.sp)
                    }
                }
                Spacer(Modifier.height(12.dp))
            }

            // ---------- DRAWER ----------
            if (p.value > 0f) Drawer(
                apps, cfg, upd, open, { showSettings = true },
                Modifier.graphicsLayer { translationY = (1f - p.value) * hPx; alpha = (p.value * 2f).coerceIn(0f, 1f) },
                dragMod
            )

            // ---------- SETTINGS ----------
            AnimatedVisibility(showSettings, enter = slideInVertically { it } + fadeIn(), exit = slideOutVertically { it } + fadeOut()) {
                SettingsSheet(cfg, upd, apps) { showSettings = false }
            }
        }
    }
}

// ---------------------------------------------------------------- drawer

@Composable
fun AppMenu(a: AppItem, open: Boolean, cfg: Prefs, upd: ((Prefs) -> Prefs) -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    fun sys(i: Intent) { try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}; onDismiss() }
    val game = isGame(a, cfg)
    DropdownMenu(expanded = open, onDismissRequest = onDismiss) {
        DropdownMenuItem(text = { Text(if (a.pkg in cfg.pins) "Unpin from home" else "Pin to home") },
            onClick = { upd { it.copy(pins = it.pins.toggle(a.pkg)) }; onDismiss() })
        DropdownMenuItem(text = { Text(if (game) "Remove from Games" else "Add to Games") },
            onClick = {
                upd { if (game) it.copy(gAdd = it.gAdd - a.pkg, gRem = it.gRem + a.pkg) else it.copy(gAdd = it.gAdd + a.pkg, gRem = it.gRem - a.pkg) }
                onDismiss()
            })
        DropdownMenuItem(text = { Text("Hide app") },
            onClick = { upd { it.copy(hidden = it.hidden + a.pkg, pins = it.pins - a.pkg) }; onDismiss() })
        DropdownMenuItem(text = { Text("App info") },
            onClick = { sys(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}"))) })
        DropdownMenuItem(text = { Text("Uninstall") },
            onClick = { sys(Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}"))) })
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Drawer(apps: List<AppItem>, cfg: Prefs, upd: ((Prefs) -> Prefs) -> Unit, onOpen: (AppItem) -> Unit, onSettings: () -> Unit, modifier: Modifier, header: Modifier) {
    val ctx = LocalContext.current
    var q by remember { mutableStateOf("") }
    var tab by remember { mutableIntStateOf(0) }
    var menuFor by remember { mutableStateOf<AppItem?>(null) }
    val list = remember(apps, q, tab, cfg.hidden, cfg.gAdd, cfg.gRem) {
        apps.filter { it.pkg !in cfg.hidden && (tab == 0 || isGame(it, cfg)) && (q.isBlank() || it.label.contains(q.trim(), true)) }
    }
    fun web() {
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q.trim()))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {}
    }

    Column(modifier.fillMaxSize()
        .background(Brush.verticalGradient(listOf(Ink.copy(.35f), Ink.copy(.72f))))
        .windowInsetsPadding(WindowInsets.systemBars).imePadding().padding(horizontal = 16.dp)) {
        Column(header.fillMaxWidth()) {
            Box(Modifier.align(Alignment.CenterHorizontally).padding(top = 10.dp, bottom = 12.dp).size(40.dp, 5.dp).clip(CircleShape).background(Color.White.copy(.5f)))
            Row(verticalAlignment = Alignment.CenterVertically) {
                BasicTextField(
                    q, { q = it }, singleLine = true,
                    textStyle = TextStyle(color = Color.White, fontSize = 16.sp), cursorBrush = SolidColor(cfg.color),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { if (list.isEmpty()) web() else onOpen(list.first()) }),
                    modifier = Modifier.weight(1f).glass(RoundedCornerShape(26.dp)).padding(horizontal = 18.dp, vertical = 14.dp),
                    decorationBox = { inner -> Box { if (q.isEmpty()) Text("Search apps…", color = Color.White.copy(.5f)); inner() } }
                )
                Spacer(Modifier.width(10.dp))
                Box(Modifier.size(48.dp).glass(CircleShape).clickable { onSettings() }, contentAlignment = Alignment.Center) {
                    Text("⚙", color = Color.White, fontSize = 20.sp)
                }
            }
            Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("All", "Games").forEachIndexed { i, t ->
                    Box(Modifier.clip(CircleShape).background(if (i == tab) cfg.color else Color.White.copy(.14f)).clickable { tab = i }.padding(horizontal = 18.dp, vertical = 8.dp)) {
                        Text(t, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
        if (list.isEmpty()) {
            if (q.isNotBlank()) Box(Modifier.padding(top = 16.dp).glass(RoundedCornerShape(22.dp)).clickable { web() }.padding(horizontal = 18.dp, vertical = 14.dp)) {
                Text("Search the web for “${q.trim()}”", color = Color.White)
            } else if (tab == 1) Text("No games yet. Long-press an app, then choose Add to Games.", color = Color.White.copy(.7f), modifier = Modifier.padding(top = 24.dp)) else Unit
        } else if (cfg.list) {
            LazyColumn(contentPadding = PaddingValues(top = 14.dp, bottom = 24.dp)) {
                items(list, key = { it.pkg + it.cls }) { a ->
                    Box(Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth().press({ onOpen(a) }, { menuFor = a }).padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            IconTile(a)
                            Spacer(Modifier.width(16.dp))
                            Text(a.label, color = Color.White, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        AppMenu(a, menuFor == a, cfg, upd) { menuFor = null }
                    }
                }
            }
        } else {
            LazyVerticalGrid(GridCells.Fixed(cfg.cols), contentPadding = PaddingValues(top = 14.dp, bottom = 24.dp)) {
                items(list, key = { it.pkg + it.cls }) { a ->
                    Box(Modifier.fillMaxWidth()) {
                        AppCell(a, Modifier.fillMaxWidth(), { onOpen(a) }, { menuFor = a })
                        AppMenu(a, menuFor == a, cfg, upd) { menuFor = null }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- settings

@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    val c = LocalCfg.current.color
    Spacer(Modifier.height(14.dp))
    Text(title.uppercase(), color = c, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp, modifier = Modifier.padding(start = 6.dp, bottom = 6.dp))
    Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(24.dp)).padding(horizontal = 16.dp, vertical = 10.dp), content = content)
}

@Composable
fun SwitchRow(title: String, v: Boolean, on: (Boolean) -> Unit) {
    val c = LocalCfg.current.color
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Color.White, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Switch(v, on, colors = SwitchDefaults.colors(checkedTrackColor = c, checkedThumbColor = Color.White))
    }
}

@Composable
fun SliderRow(title: String, v: Float, range: ClosedFloatingPointRange<Float>, label: String, on: (Float) -> Unit) {
    val c = LocalCfg.current.color
    Column(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 6.dp)) {
            Text(title, color = Color.White, fontSize = 15.sp, modifier = Modifier.weight(1f))
            Text(label, color = Color.White.copy(.6f), fontSize = 13.sp)
        }
        Slider(v, on, valueRange = range, colors = SliderDefaults.colors(thumbColor = c, activeTrackColor = c, inactiveTrackColor = Color.White.copy(.2f)))
    }
}

@Composable
fun ChoiceRow(title: String, options: List<String>, sel: Int, on: (Int) -> Unit) {
    val c = LocalCfg.current.color
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Text(title, color = Color.White, fontSize = 15.sp)
        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEachIndexed { i, o ->
                Box(Modifier.clip(CircleShape).background(if (i == sel) c else Color.White.copy(.12f)).clickable { on(i) }.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Text(o, color = Color.White, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
fun ActionRow(title: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onClick() }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Color.White, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Text("›", color = Color.White.copy(.5f), fontSize = 20.sp)
    }
}

@Composable
fun SettingsSheet(cfg: Prefs, upd: ((Prefs) -> Prefs) -> Unit, apps: List<AppItem>, onClose: () -> Unit) {
    val ctx = LocalContext.current
    fun go(i: Intent) { try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {} }
    Column(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Ink.copy(.86f), Ink.copy(.97f))))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
            .windowInsetsPadding(WindowInsets.systemBars).padding(horizontal = 16.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("CATOS", color = cfg.color, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
                Text("Settings", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Light)
            }
            Box(Modifier.size(42.dp).glass(CircleShape).clickable { onClose() }, contentAlignment = Alignment.Center) {
                Text("✕", color = Color.White, fontSize = 16.sp)
            }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
            Section("Appearance") {
                Text("Accent colour", color = Color.White, fontSize = 15.sp)
                Row(Modifier.padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Accents.forEachIndexed { i, c ->
                        Box(Modifier.size(34.dp).clip(CircleShape).background(c)
                            .then(if (i == cfg.accent) Modifier.border(3.dp, Color.White, CircleShape) else Modifier)
                            .clickable { upd { it.copy(accent = i) } })
                    }
                }
                SliderRow("Glass strength", cfg.glass, 0.04f..0.35f, "${(cfg.glass * 100).toInt()}%") { v -> upd { it.copy(glass = v) } }
                SliderRow("Wallpaper dim", cfg.dim, 0f..0.7f, "${(cfg.dim * 100).toInt()}%") { v -> upd { it.copy(dim = v) } }
                SliderRow("Icon size", cfg.iconSize.toFloat(), 36f..64f, "${cfg.iconSize}dp") { v -> upd { it.copy(iconSize = v.toInt()) } }
                ChoiceRow("Icon shape", listOf("Squircle", "Circle", "Square"), cfg.shape) { i -> upd { it.copy(shape = i) } }
                SwitchRow("Show app names", cfg.labels) { b -> upd { it.copy(labels = b) } }
                SwitchRow("Haptic feedback", cfg.haptic) { b -> upd { it.copy(haptic = b) } }
            }
            Section("Home screen") {
                SwitchRow("Clock card", cfg.clock) { b -> upd { it.copy(clock = b) } }
                SwitchRow("24-hour clock", cfg.h24) { b -> upd { it.copy(h24 = b) } }
                SwitchRow("Show date", cfg.date) { b -> upd { it.copy(date = b) } }
                SwitchRow("Dock", cfg.dock) { b -> upd { it.copy(dock = b) } }
            }
            Section("App drawer") {
                ChoiceRow("Columns", listOf("3", "4", "5", "6"), (cfg.cols - 3).coerceIn(0, 3)) { i -> upd { it.copy(cols = i + 3) } }
                SwitchRow("List view", cfg.list) { b -> upd { it.copy(list = b) } }
                SliderRow("Background blur", cfg.blur.toFloat(), 0f..150f, if (cfg.blur == 0) "Off" else "${cfg.blur}") { v -> upd { it.copy(blur = v.toInt()) } }
            }
            Section("Games") {
                SwitchRow("Show Games on home", cfg.games) { b -> upd { it.copy(games = b) } }
                Text("Games are found automatically. To fix one, long-press it in the drawer and choose Add to Games or Remove from Games.",
                    color = Color.White.copy(.6f), fontSize = 13.sp, modifier = Modifier.padding(bottom = 6.dp))
            }
            Section("Gestures") {
                SwitchRow("Swipe down for notifications", cfg.notif) { b -> upd { it.copy(notif = b) } }
            }
            Section("Hidden apps") {
                val hidden = apps.filter { it.pkg in cfg.hidden }
                if (hidden.isEmpty()) Text("None. Long-press an app in the drawer, then choose Hide app.", color = Color.White.copy(.6f), fontSize = 13.sp, modifier = Modifier.padding(bottom = 6.dp))
                hidden.forEach { a ->
                    Row(Modifier.fillMaxWidth().clickable { upd { it.copy(hidden = it.hidden - a.pkg) } }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Image(a.icon, null, Modifier.size(32.dp))
                        Spacer(Modifier.width(12.dp))
                        Text(a.label, color = Color.White, modifier = Modifier.weight(1f))
                        Text("Unhide", color = cfg.color, fontSize = 13.sp)
                    }
                }
            }
            Section("System") {
                ActionRow("Change wallpaper") { go(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper")) }
                ActionRow("Default home app") { go(Intent(Settings.ACTION_HOME_SETTINGS)) }
                ActionRow("Reset appearance") { upd { Prefs(pins = it.pins, hidden = it.hidden, gAdd = it.gAdd, gRem = it.gRem) } }
                Text("CATOS Launcher v1.1", color = Color.White.copy(.4f), fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
            }
        }
    }
}
