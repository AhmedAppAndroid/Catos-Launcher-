plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.ahmed.catoslauncher"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.ahmed.catoslauncher"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "1.1"
    }
    // Fixed key: every build is signed the same, so future updates install over this one.
    signingConfigs {
        create("catos") {
            storeFile = file("catos.jks")
            storePassword = "catos123"
            keyAlias = "catos"
            keyPassword = "catos123"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("catos") }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
}
