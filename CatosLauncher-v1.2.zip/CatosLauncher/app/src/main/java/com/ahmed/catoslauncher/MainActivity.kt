package com.ahmed.catoslauncher

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.ColorDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.*
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import kotlinx.coroutines.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs

// ---------------------------------------------------------------- theme / settings

val Accents = listOf(
    Color(0xFFFF2E93), Color(0xFF8A2BE2), Color(0xFF00E5FF), Color(0xFF34D399),
    Color(0xFFFFB020), Color(0xFF3B82F6), Color(0xFFFFD700) // last one is the secret gold
)
val Purple = Color(0xFF8A2BE2)
val Ink = Color(0xFF12071F)
val GameHints = listOf("minecraft", "roblox", "pubg", "freefire", "garena", "supercell", "mobilelegends", "moonton", "activision", "epicgames", "gameloft", ".game")
private const val SEP = "\u0001"

private fun SharedPreferences.strs(k: String): Set<String> = getStringSet(k, emptySet())?.toSet() ?: emptySet()

data class Prefs(
    val accent: Int = 0, val glass: Float = .12f, val blur: Int = 90, val dim: Float = .2f,
    val iconSize: Int = 44, val cols: Int = 4, val shape: Int = 0,
    val labels: Boolean = true, val list: Boolean = false,
    val clock: Boolean = true, val clockStyle: Int = 0, val h24: Boolean = true, val date: Boolean = true, val battery: Boolean = true,
    val dock: Boolean = true, val games: Boolean = true, val haptic: Boolean = true, val notif: Boolean = true,
    val lockTap: Boolean = false, val kb: Boolean = false,
    val unlocked: Boolean = false, val lab: Boolean = false, val wobble: Boolean = false, val party: Boolean = false,
    val pins: Set<String> = emptySet(), val hidden: Set<String> = emptySet(),
    val gAdd: Set<String> = emptySet(), val gRem: Set<String> = emptySet(),
    val dockApps: Set<String> = emptySet(), val renames: Set<String> = emptySet()
) {
    val color: Color get() = Accents[accent.coerceIn(0, Accents.lastIndex)]

    val names: Map<String, String> by lazy {
        renames.mapNotNull { e ->
            val i = e.indexOf(SEP)
            if (i > 0) e.substring(0, i) to e.substring(i + 1) else null
        }.toMap()
    }

    fun labelOf(a: AppItem): String = names[a.pkg] ?: a.label

    fun save(p: SharedPreferences) {
        p.edit().putInt("accent", accent).putFloat("glass", glass).putInt("blur", blur).putFloat("dim", dim)
            .putInt("iconSize", iconSize).putInt("cols", cols).putInt("shape", shape)
            .putBoolean("labels", labels).putBoolean("list", list)
            .putBoolean("clock", clock).putInt("clockStyle", clockStyle).putBoolean("h24", h24)
            .putBoolean("date", date).putBoolean("battery", battery)
            .putBoolean("dock", dock).putBoolean("games", games).putBoolean("haptic", haptic).putBoolean("notif", notif)
            .putBoolean("lockTap", lockTap).putBoolean("kb", kb)
            .putBoolean("unlocked", unlocked).putBoolean("lab", lab).putBoolean("wobble", wobble).putBoolean("party", party)
            .putStringSet("pins", pins).putStringSet("hidden", hidden)
            .putStringSet("gAdd", gAdd).putStringSet("gRem", gRem)
            .putStringSet("dockApps", dockApps).putStringSet("renames", renames).apply()
    }

    companion object {
        fun load(p: SharedPreferences) = Prefs(
            accent = p.getInt("accent", 0), glass = p.getFloat("glass", .12f), blur = p.getInt("blur", 90), dim = p.getFloat("dim", .2f),
            iconSize = p.getInt("iconSize", 44), cols = p.getInt("cols", 4), shape = p.getInt("shape", 0),
            labels = p.getBoolean("labels", true), list = p.getBoolean("list", false),
            clock = p.getBoolean("clock", true), clockStyle = p.getInt("clockStyle", 0), h24 = p.getBoolean("h24", true),
            date = p.getBoolean("date", true), battery = p.getBoolean("battery", true),
            dock = p.getBoolean("dock", true), games = p.getBoolean("games", true),
            haptic = p.getBoolean("haptic", true), notif = p.getBoolean("notif", true),
            lockTap = p.getBoolean("lockTap", false), kb = p.getBoolean("kb", false),
            unlocked = p.getBoolean("unlocked", false), lab = p.getBoolean("lab", false),
            wobble = p.getBoolean("wobble", false), party = p.getBoolean("party", false),
            pins = p.strs("pins"), hidden = p.strs("hidden"), gAdd = p.strs("gAdd"), gRem = p.strs("gRem"),
            dockApps = p.strs("dockApps"), renames = p.strs("renames")
        )
    }
}

val LocalCfg = compositionLocalOf { Prefs() }

class AppItem(val label: String, val pkg: String, val cls: String, val icon: ImageBitmap, val auto: Boolean)
class DockItem(val intent: Intent, val icon: ImageBitmap)

fun isGame(a: AppItem, c: Prefs) = a.pkg !in c.gRem && (a.auto || a.pkg in c.gAdd)
fun Set<String>.toggle(k: String): Set<String> = if (k in this) this - k else this + k
fun tileShape(c: Prefs): Shape = RoundedCornerShape(when (c.shape) { 0 -> 30; 1 -> 50; else -> 10 })

fun preset(p: Prefs, i: Int): Prefs = when (i) {
    0 -> p.copy(accent = 0, glass = .12f, dim = .20f, blur = 90, shape = 0)
    1 -> p.copy(accent = 2, glass = .16f, dim = .30f, blur = 110, shape = 1)
    2 -> p.copy(accent = 3, glass = .08f, dim = .55f, blur = 60, shape = 2)
    3 -> p.copy(accent = 4, glass = .14f, dim = .25f, blur = 100, shape = 0)
    else -> p.copy(accent = 5, glass = .24f, dim = .10f, blur = 140, shape = 0)
}

// ---------------------------------------------------------------- tiny calculator (search bar)

private class Calc(val s: String) {
    var i = 0
    fun parse(): Double { val v = expr(); if (i != s.length) throw IllegalArgumentException(); return v }
    fun expr(): Double {
        var v = term()
        while (i < s.length && (s[i] == '+' || s[i] == '-')) {
            val op = s[i]; i++
            val r = term()
            v = if (op == '+') v + r else v - r
        }
        return v
    }
    fun term(): Double {
        var v = pow()
        while (i < s.length && (s[i] == '*' || s[i] == '/' || s[i] == '%')) {
            val op = s[i]; i++
            val r = pow()
            v = when (op) { '*' -> v * r; '/' -> v / r; else -> v % r }
        }
        return v
    }
    fun pow(): Double {
        val b = unary()
        if (i < s.length && s[i] == '^') { i++; return Math.pow(b, pow()) }
        return b
    }
    fun unary(): Double {
        if (i < s.length && s[i] == '-') { i++; return -unary() }
        if (i < s.length && s[i] == '+') { i++; return unary() }
        return atom()
    }
    fun atom(): Double {
        if (i < s.length && s[i] == '(') {
            i++
            val v = expr()
            if (i >= s.length || s[i] != ')') throw IllegalArgumentException()
            i++
            return v
        }
        val st = i
        while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
        if (st == i) throw IllegalArgumentException()
        return s.substring(st, i).toDouble()
    }
}

fun calc(src: String): Double? {
    val s = src.replace(" ", "").replace("×", "*").replace("÷", "/").replace("x", "*")
    if (s.length < 3 || s.none { it in "+-*/%^" } || !s.all { it.isDigit() || it in "+-*/%^()." }) return null
    return try { Calc(s).parse().takeIf { it.isFinite() } } catch (_: Exception) { null }
}

fun fmt(v: Double): String =
    if (v == Math.floor(v) && abs(v) < 1e15) v.toLong().toString()
    else String.format(Locale.US, "%.8f", v).trimEnd('0').trimEnd('.')

// ---------------------------------------------------------------- activity

class LockAdmin : DeviceAdminReceiver()

class MainActivity : ComponentActivity() {
    private val tick = mutableIntStateOf(0)
    private val home = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Accents[0], surface = Ink)) {
                Launcher(this, tick.intValue, home.intValue)
            }
        }
    }

    override fun onResume() { super.onResume(); tick.intValue++ }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.hasCategory(Intent.CATEGORY_HOME)) home.intValue++
    }

    /** Real background blur of the wallpaper (Android 12+). Silently ignored where unsupported. */
    fun setBlur(r: Int) {
        if (Build.VERSION.SDK_INT < 31) return
        runOnUiThread {
            try {
                window.setBackgroundDrawable(ColorDrawable(if (r > 0) 0x33000000 else 0))
                window.setBackgroundBlurRadius(r)
            } catch (_: Throwable) {}
        }
    }

    /** Pull down the notification shade (works on most phones). */
    fun expandNotifications() {
        try {
            val sb = getSystemService("statusbar")
            Class.forName("android.app.StatusBarManager").getMethod("expandNotificationsPanel").invoke(sb)
        } catch (_: Throwable) {}
    }

    private fun adminCn() = ComponentName(this, LockAdmin::class.java)
    private fun dpm() = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager

    /** Asks Android to grant "lock screen" permission (only if not granted yet). */
    fun ensureLockAdmin() {
        try {
            if (!dpm().isAdminActive(adminCn())) {
                startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminCn())
                    .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Lets CATOS Launcher lock your screen when you double-tap."))
            }
        } catch (_: Throwable) {}
    }

    fun lockScreen() {
        try {
            if (dpm().isAdminActive(adminCn())) dpm().lockNow() else ensureLockAdmin()
        } catch (_: Throwable) {}
    }

    fun removeLockAdmin() { try { dpm().removeActiveAdmin(adminCn()) } catch (_: Throwable) {} }
}

@Suppress("DEPRECATION")
fun loadApps(ctx: Context): List<AppItem> {
    val pm = ctx.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0)
        .filter { it.activityInfo.packageName != ctx.packageName }
        .map {
            val ai = it.activityInfo.applicationInfo
            val pkg = it.activityInfo.packageName
            val g = ai.category == ApplicationInfo.CATEGORY_GAME ||
                (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0 ||
                GameHints.any { h -> pkg.contains(h, true) }
            AppItem(it.loadLabel(pm).toString(), pkg, it.activityInfo.name, it.loadIcon(pm).toBitmap(128, 128).asImageBitmap(), g)
        }
        .sortedBy { it.label.lowercase() }
}

fun startApp(ctx: Context, a: AppItem) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(a.pkg, a.cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED))
    } catch (_: Exception) {}
}

// ---------------------------------------------------------------- small building blocks

/** Liquid-glass look: translucent gradient fill, top gloss, bright rim light. */
@Composable
fun Modifier.glass(shape: Shape, extra: Float = 0f): Modifier {
    val a = LocalCfg.current.glass + extra
    return this
        .clip(shape)
        .background(Brush.linearGradient(listOf(Color.White.copy(a + .10f), Color.White.copy(a * .4f))))
        .drawBehind { drawRect(Brush.verticalGradient(listOf(Color.White.copy(.16f), Color.Transparent), endY = size.height * .45f)) }
        .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(.7f), Color.White.copy(.06f), Color.White.copy(.3f))), shape)
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Modifier.press(onClick: () -> Unit, onLong: (() -> Unit)? = null): Modifier {
    val src = remember { MutableInteractionSource() }
    val down by src.collectIsPressedAsState()
    val hf = LocalHapticFeedback.current
    val haptic = LocalCfg.current.haptic
    val s by animateFloatAsState(if (down) .86f else 1f, spring(0.5f, 500f), label = "press")
    val longCb: (() -> Unit)? = onLong?.let { f -> { if (haptic) hf.performHapticFeedback(HapticFeedbackType.LongPress); f() } }
    return this.graphicsLayer { scaleX = s; scaleY = s }
        .combinedClickable(interactionSource = src, indication = null, onClick = onClick, onLongClick = longCb)
}

@Composable
fun IconTile(a: AppItem) {
    val cfg = LocalCfg.current
    val wob: State<Float>? = if (cfg.wobble)
        rememberInfiniteTransition(label = "wob").animateFloat(-3f, 3f, infiniteRepeatable(tween(130, easing = LinearEasing), RepeatMode.Reverse), label = "wr")
    else null
    Box(Modifier.size((cfg.iconSize + 18).dp).graphicsLayer { rotationZ = wob?.value ?: 0f }.glass(tileShape(cfg)), contentAlignment = Alignment.Center) {
        Image(a.icon, null, Modifier.size(cfg.iconSize.dp))
    }
}

@Composable
fun AppCell(a: AppItem, modifier: Modifier, onClick: () -> Unit, onLong: (() -> Unit)? = null) {
    val cfg = LocalCfg.current
    Column(modifier.press(onClick, onLong).padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        IconTile(a)
        if (cfg.labels) {
            Spacer(Modifier.height(5.dp))
            Text(cfg.labelOf(a), color = Color.White, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun batteryText(): String {
    val ctx = LocalContext.current
    var txt by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        while (true) {
            val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            if (i != null) {
                val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
                if (l >= 0 && sc > 0) txt = (if (charging) "⚡ " else "🔋 ") + (l * 100 / sc) + "%"
            }
            delay(30_000)
        }
    }
    return txt
}

@Composable
fun ClockCard(onEgg: () -> Unit) {
    val cfg = LocalCfg.current
    val bat = batteryText()
    var now by remember { mutableStateOf(Date()) }
    var taps by remember { mutableIntStateOf(0) }
    var last by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) { while (true) { now = Date(); delay(10_000) } }
    val hhmm = SimpleDateFormat("HH:mm", Locale.US).format(now)
    val shown = SimpleDateFormat(if (cfg.h24) "HH:mm" else "h:mm", Locale.getDefault()).format(now)
    val dateTxt = if (cfg.date) SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(now) else ""
    val batTxt = if (cfg.battery) bat else ""
    val sub = if (dateTxt.isNotEmpty() && batTxt.isNotEmpty()) dateTxt + "  ·  " + batTxt else dateTxt + batTxt
    val box = if (cfg.clockStyle == 0) Modifier.fillMaxWidth().glass(RoundedCornerShape(32.dp)).padding(horizontal = 26.dp, vertical = 20.dp)
              else Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 10.dp)
    Column(box) {
        Text(
            if (hhmm == "13:37") "L33T" else "CATOS", color = cfg.color, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp,
            modifier = Modifier.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                val t = System.currentTimeMillis()
                taps = if (t - last < 900) taps + 1 else 1
                last = t
                if (taps >= 7) { taps = 0; onEgg() }
            }.padding(end = 24.dp, top = 4.dp, bottom = 4.dp)
        )
        Text(shown, color = Color.White, fontSize = if (cfg.clockStyle == 0) 64.sp else 76.sp, fontWeight = FontWeight.Light)
        if (sub.isNotEmpty()) Text(sub, color = Color.White.copy(.75f), fontSize = 16.sp)
    }
}

// ---------------------------------------------------------------- secret effects

@Composable
fun Rain(glyphs: List<String>, color: Color, n: Int = 28) {
    val dens = LocalDensity.current
    val conf = LocalConfiguration.current
    val hPx = with(dens) { conf.screenHeightDp.dp.toPx() }
    val wPx = with(dens) { conf.screenWidthDp.dp.toPx() }
    val t = remember { Animatable(0f) }
    LaunchedEffect(Unit) { t.animateTo(1f, tween(4000, easing = LinearEasing)) }
    val seeds = remember { List(n) { Triple(Math.random().toFloat(), 0.6f + Math.random().toFloat() * 0.9f, 18 + (Math.random() * 22).toInt()) } }
    Box(Modifier.fillMaxSize()) {
        seeds.forEachIndexed { i, s ->
            Text(
                glyphs[i % glyphs.size], color = color, fontSize = s.third.sp,
                modifier = Modifier.graphicsLayer {
                    translationX = s.first * (wPx - 60f)
                    translationY = -90f + t.value * s.second * (hPx + 180f)
                    alpha = 1f - t.value * 0.5f
                }
            )
        }
    }
}

@Composable
fun PartyLights() {
    val h = rememberInfiniteTransition(label = "party").animateFloat(0f, 360f, infiniteRepeatable(tween(6000, easing = LinearEasing)), label = "ph")
    Box(Modifier.fillMaxSize().drawBehind {
        val v = h.value
        drawRect(Brush.linearGradient(listOf(
            Color.hsv(v, .8f, 1f, .28f),
            Color.hsv((v + 120f) % 360f, .8f, 1f, .28f),
            Color.hsv((v + 240f) % 360f, .8f, 1f, .28f)
        )))
    })
}

// ---------------------------------------------------------------- launcher root

@Composable
fun Launcher(act: MainActivity, tick: Int, homeTick: Int) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("catos", Context.MODE_PRIVATE) }
    var cfg by remember { mutableStateOf(Prefs.load(prefs)) }
    val upd: ((Prefs) -> Prefs) -> Unit = { f -> cfg = f(cfg); cfg.save(prefs) }
    var apps by remember { mutableStateOf(emptyList<AppItem>()) }
    var usage by remember { mutableStateOf(emptyMap<String, Int>()) }
    var showSettings by remember { mutableStateOf(false) }
    var showTools by remember { mutableStateOf(false) }
    var rain by remember { mutableStateOf("") }
    var eggText by remember { mutableStateOf("") }
    val flash = remember { Animatable(0f) }
    val shake = remember { Animatable(0f) }

    LaunchedEffect(tick) {
        apps = withContext(Dispatchers.Default) { loadApps(ctx) }
        usage = prefs.all.filterKeys { it.startsWith("use_") }
            .mapKeys { it.key.removePrefix("use_") }
            .mapValues { (it.value as? Int) ?: 0 }
    }

    val dock = remember(tick) {
        val pm = ctx.packageManager
        listOf(Intent(Intent.ACTION_DIAL), Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")), Intent(MediaStore.ACTION_IMAGE_CAPTURE))
            .mapNotNull { i ->
                pm.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)?.takeIf { it.activityInfo.packageName != "android" }
                    ?.let { DockItem(i, it.loadIcon(pm).toBitmap(128, 128).asImageBitmap()) }
            }
    }

    val p = remember { Animatable(0f) }                       // 0 = home, 1 = drawer open
    var startP by remember { mutableFloatStateOf(0f) }
    val hPx = with(LocalDensity.current) { LocalConfiguration.current.screenHeightDp.dp.toPx() }
    val drag = rememberDraggableState { d -> scope.launch { p.snapTo((p.value - d / hPx * 1.25f).coerceIn(0f, 1f)) } }
    val stop: suspend CoroutineScope.(Float) -> Unit = { v ->
        if (cfg.notif && startP < .05f && p.value < .05f && v > 1400f) act.expandNotifications()
        else p.animateTo(when { v < -1200f -> 1f; v > 1200f -> 0f; p.value > .4f -> 1f; else -> 0f }, spring(.82f, 280f))
    }
    val dragMod = Modifier.draggable(drag, Orientation.Vertical, onDragStarted = { _ -> startP = p.value }, onDragStopped = stop)

    LaunchedEffect(homeTick) { if (homeTick > 0) { showSettings = false; showTools = false; p.animateTo(0f) } }
    LaunchedEffect(cfg.blur) { snapshotFlow { p.value > 0.5f || showSettings || showTools }.collect { act.setBlur(if (it) cfg.blur else 0) } }
    BackHandler { scope.launch { p.animateTo(0f) } }
    BackHandler(enabled = showSettings) { showSettings = false }
    BackHandler(enabled = showTools) { showTools = false }

    val open = { a: AppItem ->
        startApp(ctx, a)
        val n = (usage[a.pkg] ?: 0) + 1
        usage = usage + (a.pkg to n)
        prefs.edit().putInt("use_" + a.pkg, n).apply()
        scope.launch { delay(250); p.snapTo(0f) }
        Unit
    }

    // ---- easter eggs ----
    val egg: (String) -> Unit = { k ->
        scope.launch {
            when (k) {
                "cat" -> {
                    if (!cfg.unlocked) {
                        upd { it.copy(unlocked = true) }
                        Toast.makeText(ctx, "🐱 Secret gold accent unlocked! Check Settings.", Toast.LENGTH_LONG).show()
                    }
                    rain = "cat"; delay(4300); rain = ""
                }
                "matrix" -> { eggText = "Wake up, Neo…"; rain = "matrix"; delay(4300); rain = ""; eggText = "" }
                "creeper" -> {
                    eggText = "Ssssss…"; delay(1400)
                    eggText = "💥"; flash.snapTo(1f)
                    launch { flash.animateTo(0f, tween(800)) }
                    repeat(12) { shake.animateTo(if (it % 2 == 0) 26f else -26f, tween(35)) }
                    shake.animateTo(0f, tween(60))
                    eggText = "Aw man…"; delay(1500); eggText = ""
                }
                "credits" -> { eggText = "CATOS Launcher v1.2\nmade with 🐱 by CATOS"; delay(2600); eggText = "" }
                else -> {}
            }
        }
    }

    val pinned = apps.filter { it.pkg in cfg.pins && it.pkg !in cfg.hidden }.take(cfg.cols * 2)
    val games = apps.filter { it.pkg !in cfg.hidden && isGame(it, cfg) }
    val dockApps = apps.filter { it.pkg in cfg.dockApps && it.pkg !in cfg.hidden }.take(5)

    CompositionLocalProvider(LocalCfg provides cfg) {
        Box(Modifier.fillMaxSize().graphicsLayer { translationX = shake.value }) {
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Purple.copy(.22f), Ink.copy(.55f)))))
            Box(Modifier.fillMaxSize().background(Color.Black.copy(cfg.dim)))
            if (cfg.party) PartyLights()

            // ---------- HOME ----------
            Column(
                Modifier.fillMaxSize().then(dragMod)
                    .pointerInput(cfg.lockTap) { detectTapGestures(onDoubleTap = { if (cfg.lockTap) act.lockScreen() }) }
                    .graphicsLayer { alpha = 1f - p.value * .7f; val s = 1f - p.value * .06f; scaleX = s; scaleY = s }
                    .windowInsetsPadding(WindowInsets.systemBars).padding(horizontal = 20.dp)
            ) {
                Spacer(Modifier.height(24.dp))
                Column(Modifier.weight(1f).clipToBounds()) {
                    if (cfg.clock) { ClockCard { egg("cat") }; Spacer(Modifier.height(20.dp)) }
                    if (pinned.isNotEmpty()) Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(32.dp)).padding(10.dp)) {
                        pinned.chunked(cfg.cols).forEach { row ->
                            Row(Modifier.fillMaxWidth()) {
                                row.forEach { a -> AppCell(a, Modifier.weight(1f), { open(a) }, { upd { it.copy(pins = it.pins - a.pkg) } }) }
                                repeat(cfg.cols - row.size) { Spacer(Modifier.weight(1f)) }
                            }
                        }
                    }
                    if (cfg.games && games.isNotEmpty()) {
                        Spacer(Modifier.height(14.dp))
                        Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(32.dp)).padding(top = 14.dp, bottom = 4.dp)) {
                            Text("GAMES", color = cfg.color, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp, modifier = Modifier.padding(start = 22.dp))
                            LazyRow(contentPadding = PaddingValues(horizontal = 10.dp)) {
                                items(games, key = { it.pkg + it.cls }) { a -> AppCell(a, Modifier.width(78.dp), { open(a) }) }
                            }
                        }
                    }
                }
                if (cfg.dock && (dockApps.isNotEmpty() || dock.isNotEmpty())) {
                    Row(Modifier.fillMaxWidth().glass(RoundedCornerShape(36.dp), .02f).padding(horizontal = 14.dp, vertical = 12.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                        if (dockApps.isNotEmpty()) dockApps.forEach { a ->
                            Image(a.icon, null, Modifier.size(52.dp).press({ open(a) }, { upd { it.copy(dockApps = it.dockApps - a.pkg) } }))
                        } else dock.forEach { d ->
                            Image(d.icon, null, Modifier.size(52.dp).press({ try { ctx.startActivity(d.intent.apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }) } catch (_: Exception) {} }))
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.align(Alignment.CenterHorizontally), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.glass(CircleShape).clickable { scope.launch { p.animateTo(1f) } }.padding(horizontal = 22.dp, vertical = 10.dp)) {
                        Text("Swipe up for apps", color = Color.White.copy(.8f), fontSize = 12.sp)
                    }
                    Box(Modifier.size(40.dp).glass(CircleShape).clickable { showTools = true }, contentAlignment = Alignment.Center) {
                        Text("⚡", color = Color.White, fontSize = 17.sp)
                    }
                    Box(Modifier.size(40.dp).glass(CircleShape).clickable { showSettings = true }, contentAlignment = Alignment.Center) {
                        Text("⚙", color = Color.White, fontSize = 18.sp)
                    }
                }
                Spacer(Modifier.height(12.dp))
            }

            // ---------- DRAWER ----------
            if (p.value > 0f) Drawer(
                apps, usage, cfg, upd, open, { showSettings = true }, egg,
                Modifier.graphicsLayer { translationY = (1f - p.value) * hPx; alpha = (p.value * 2f).coerceIn(0f, 1f) },
                dragMod
            )

            // ---------- SHEETS ----------
            AnimatedVisibility(showSettings, enter = slideInVertically { it } + fadeIn(), exit = slideOutVertically { it } + fadeOut()) {
                SettingsSheet(
                    cfg = cfg, upd = upd, apps = apps,
                    onLock = { on -> upd { it.copy(lockTap = on) }; if (on) act.ensureLockAdmin() else act.removeLockAdmin() },
                    onLab = {
                        upd { it.copy(lab = !it.lab) }
                        Toast.makeText(ctx, if (cfg.lab) "🧪 Lab unlocked" else "Lab hidden", Toast.LENGTH_SHORT).show()
                    },
                    onClose = { showSettings = false }
                )
            }
            AnimatedVisibility(showTools, enter = slideInVertically { it } + fadeIn(), exit = slideOutVertically { it } + fadeOut()) {
                ToolsSheet(cfg, prefs) { showTools = false }
            }

            // ---------- EGG OVERLAYS ----------
            if (rain == "cat") Rain(listOf("🐱", "🐾", "😺", "😸"), Color.White)
            if (rain == "matrix") Rain(listOf("0", "1"), Color(0xFF00FF66), 60)
            if (flash.value > 0f) Box(Modifier.fillMaxSize().background(Color.White.copy(alpha = flash.value)))
            if (eggText.isNotEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(eggText, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
                    modifier = Modifier.glass(RoundedCornerShape(28.dp)).padding(horizontal = 28.dp, vertical = 20.dp))
            }
        }
    }
}

// ---------------------------------------------------------------- drawer

@Composable
fun AppMenu(a: AppItem, open: Boolean, cfg: Prefs, upd: ((Prefs) -> Prefs) -> Unit, onRename: () -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    fun sys(i: Intent) { try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}; onDismiss() }
    val game = isGame(a, cfg)
    DropdownMenu(expanded = open, onDismissRequest = onDismiss) {
        DropdownMenuItem(text = { Text(if (a.pkg in cfg.pins) "Unpin from home" else "Pin to home") },
            onClick = { upd { it.copy(pins = it.pins.toggle(a.pkg)) }; onDismiss() })
        DropdownMenuItem(text = { Text(if (a.pkg in cfg.dockApps) "Remove from dock" else "Add to dock") },
            onClick = {
                upd { if (a.pkg in it.dockApps) it.copy(dockApps = it.dockApps - a.pkg) else if (it.dockApps.size < 5) it.copy(dockApps = it.dockApps + a.pkg) else it }
                onDismiss()
            })
        DropdownMenuItem(text = { Text(if (game) "Remove from Games" else "Add to Games") },
            onClick = {
                upd { if (game) it.copy(gAdd = it.gAdd - a.pkg, gRem = it.gRem + a.pkg) else it.copy(gAdd = it.gAdd + a.pkg, gRem = it.gRem - a.pkg) }
                onDismiss()
            })
        DropdownMenuItem(text = { Text("Rename") }, onClick = { onRename(); onDismiss() })
        DropdownMenuItem(text = { Text("Hide app") },
            onClick = { upd { it.copy(hidden = it.hidden + a.pkg, pins = it.pins - a.pkg, dockApps = it.dockApps - a.pkg) }; onDismiss() })
        DropdownMenuItem(text = { Text("App info") },
            onClick = { sys(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}"))) })
        DropdownMenuItem(text = { Text("Uninstall") },
            onClick = { sys(Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}"))) })
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Drawer(
    apps: List<AppItem>, usage: Map<String, Int>, cfg: Prefs, upd: ((Prefs) -> Prefs) -> Unit,
    onOpen: (AppItem) -> Unit, onSettings: () -> Unit, onEgg: (String) -> Unit, modifier: Modifier, header: Modifier
) {
    val ctx = LocalContext.current
    var q by remember { mutableStateOf("") }
    var tab by remember { mutableIntStateOf(0) }
    var menuFor by remember { mutableStateOf<AppItem?>(null) }
    var renameFor by remember { mutableStateOf<AppItem?>(null) }
    val focus = remember { FocusRequester() }
    val list = remember(apps, q, tab, cfg, usage) {
        val base = apps.filter { it.pkg !in cfg.hidden }
        val src = when (tab) {
            1 -> base.filter { isGame(it, cfg) }
            2 -> base.filter { (usage[it.pkg] ?: 0) > 0 }.sortedByDescending { usage[it.pkg] ?: 0 }.take(16)
            else -> base
        }
        val ql = q.trim()
        val found = if (ql.isEmpty()) src else src.filter { cfg.labelOf(it).contains(ql, true) }
        if (tab == 2) found else found.sortedBy { cfg.labelOf(it).lowercase() }
    }
    val cv = remember(q) { calc(q) }
    fun web() {
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q.trim()))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {}
    }

    LaunchedEffect(Unit) { if (cfg.kb) { delay(250); try { focus.requestFocus() } catch (_: Exception) {} } }
    LaunchedEffect(q) {
        when (q.trim().lowercase()) {
            "meow" -> { onEgg("cat"); q = "" }
            "creeper" -> { onEgg("creeper"); q = "" }
            "matrix" -> { onEgg("matrix"); q = "" }
            "catos" -> { onEgg("credits"); q = "" }
            else -> {}
        }
    }

    Column(modifier.fillMaxSize()
        .background(Brush.verticalGradient(listOf(Ink.copy(.35f), Ink.copy(.72f))))
        .windowInsetsPadding(WindowInsets.systemBars).imePadding().padding(horizontal = 16.dp)) {
        Column(header.fillMaxWidth()) {
            Box(Modifier.align(Alignment.CenterHorizontally).padding(top = 10.dp, bottom = 12.dp).size(40.dp, 5.dp).clip(CircleShape).background(Color.White.copy(.5f)))
            Row(verticalAlignment = Alignment.CenterVertically) {
                BasicTextField(
                    q, { q = it }, singleLine = true,
                    textStyle = TextStyle(color = Color.White, fontSize = 16.sp), cursorBrush = SolidColor(cfg.color),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { if (list.isEmpty()) web() else onOpen(list.first()) }),
                    modifier = Modifier.weight(1f).focusRequester(focus).glass(RoundedCornerShape(26.dp)).padding(horizontal = 18.dp, vertical = 14.dp),
                    decorationBox = { inner -> Box { if (q.isEmpty()) Text("Search apps…", color = Color.White.copy(.5f)); inner() } }
                )
                Spacer(Modifier.width(10.dp))
                Box(Modifier.size(48.dp).glass(CircleShape).clickable { onSettings() }, contentAlignment = Alignment.Center) {
                    Text("⚙", color = Color.White, fontSize = 20.sp)
                }
            }
            Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("All", "Games", "Top").forEachIndexed { i, t ->
                    Box(Modifier.clip(CircleShape).background(if (i == tab) cfg.color else Color.White.copy(.14f)).clickable { tab = i }.padding(horizontal = 18.dp, vertical = 8.dp)) {
                        Text(t, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
        if (cv != null) Box(
            Modifier.padding(top = 14.dp).fillMaxWidth().glass(RoundedCornerShape(22.dp)).clickable {
                (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("calc", fmt(cv)))
                Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show()
            }.padding(horizontal = 20.dp, vertical = 16.dp)
        ) {
            Text("= " + fmt(cv), color = Color.White, fontSize = 22.sp)
        }
        if (list.isEmpty()) {
            if (q.isNotBlank() && cv == null) Box(Modifier.padding(top = 16.dp).glass(RoundedCornerShape(22.dp)).clickable { web() }.padding(horizontal = 18.dp, vertical = 14.dp)) {
                Text("Search the web for “${q.trim()}”", color = Color.White)
            } else if (tab == 1 && q.isBlank()) Text("No games yet. Long-press an app, then choose Add to Games.", color = Color.White.copy(.7f), modifier = Modifier.padding(top = 24.dp))
            else if (tab == 2 && q.isBlank()) Text("Open a few apps and your most used ones show up here.", color = Color.White.copy(.7f), modifier = Modifier.padding(top = 24.dp))
            else Unit
        } else if (cfg.list) {
            LazyColumn(contentPadding = PaddingValues(top = 14.dp, bottom = 24.dp)) {
                items(list, key = { it.pkg + it.cls }) { a ->
                    Box(Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth().press({ onOpen(a) }, { menuFor = a }).padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            IconTile(a)
                            Spacer(Modifier.width(16.dp))
                            Text(cfg.labelOf(a), color = Color.White, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        AppMenu(a, menuFor == a, cfg, upd, { renameFor = a }) { menuFor = null }
                    }
                }
            }
        } else {
            LazyVerticalGrid(GridCells.Fixed(cfg.cols), contentPadding = PaddingValues(top = 14.dp, bottom = 24.dp)) {
                items(list, key = { it.pkg + it.cls }) { a ->
                    Box(Modifier.fillMaxWidth()) {
                        AppCell(a, Modifier.fillMaxWidth(), { onOpen(a) }, { menuFor = a })
                        AppMenu(a, menuFor == a, cfg, upd, { renameFor = a }) { menuFor = null }
                    }
                }
            }
        }

        renameFor?.let { a ->
            var t by remember(a) { mutableStateOf(cfg.labelOf(a)) }
            AlertDialog(
                onDismissRequest = { renameFor = null },
                title = { Text("Rename app") },
                text = { OutlinedTextField(t, { t = it }, singleLine = true) },
                confirmButton = {
                    TextButton(onClick = {
                        val keep = cfg.renames.filter { e -> !e.startsWith(a.pkg + SEP) }.toSet()
                        val nm = t.trim()
                        upd { it.copy(renames = if (nm.isEmpty() || nm == a.label) keep else keep + (a.pkg + SEP + nm)) }
                        renameFor = null
                    }) { Text("Save") }
                },
                dismissButton = { TextButton(onClick = { renameFor = null }) { Text("Cancel") } }
            )
        }
    }
}

// ---------------------------------------------------------------- settings + tools

@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    val c = LocalCfg.current.color
    Spacer(Modifier.height(14.dp))
    Text(title.uppercase(), color = c, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp, modifier = Modifier.padding(start = 6.dp, bottom = 6.dp))
    Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(24.dp)).padding(horizontal = 16.dp, vertical = 10.dp), content = content)
}

@Composable
fun SwitchRow(title: String, v: Boolean, on: (Boolean) -> Unit) {
    val c = LocalCfg.current.color
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Color.White, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Switch(v, on, colors = SwitchDefaults.colors(checkedTrackColor = c, checkedThumbColor = Color.White))
    }
}

@Composable
fun SliderRow(title: String, v: Float, range: ClosedFloatingPointRange<Float>, label: String, on: (Float) -> Unit) {
    val c = LocalCfg.current.color
    Column(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 6.dp)) {
            Text(title, color = Color.White, fontSize = 15.sp, modifier = Modifier.weight(1f))
            Text(label, color = Color.White.copy(.6f), fontSize = 13.sp)
        }
        Slider(v, on, valueRange = range, colors = SliderDefaults.colors(thumbColor = c, activeTrackColor = c, inactiveTrackColor = Color.White.copy(.2f)))
    }
}

@Composable
fun ChoiceRow(title: String, options: List<String>, sel: Int, on: (Int) -> Unit) {
    val c = LocalCfg.current.color
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Text(title, color = Color.White, fontSize = 15.sp)
        Row(Modifier.padding(top = 8.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEachIndexed { i, o ->
                Box(Modifier.clip(CircleShape).background(if (i == sel) c else Color.White.copy(.12f)).clickable { on(i) }.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Text(o, color = Color.White, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
fun ActionRow(title: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onClick() }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Color.White, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Text("›", color = Color.White.copy(.5f), fontSize = 20.sp)
    }
}

@Composable
fun SettingsSheet(cfg: Prefs, upd: ((Prefs) -> Prefs) -> Unit, apps: List<AppItem>, onLock: (Boolean) -> Unit, onLab: () -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var vt by remember { mutableIntStateOf(0) }
    fun go(i: Intent) { try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {} }
    Column(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Ink.copy(.86f), Ink.copy(.97f))))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
            .windowInsetsPadding(WindowInsets.systemBars).padding(horizontal = 16.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("CATOS", color = cfg.color, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
                Text("Settings", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Light)
            }
            Box(Modifier.size(42.dp).glass(CircleShape).clickable { onClose() }, contentAlignment = Alignment.Center) {
                Text("✕", color = Color.White, fontSize = 16.sp)
            }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
            Section("Themes") {
                ChoiceRow("Presets", listOf("Pink glass", "Ocean", "Matrix", "Sunset", "Frost"), -1) { i -> upd { preset(it, i) } }
            }
            Section("Appearance") {
                Text("Accent colour", color = Color.White, fontSize = 15.sp)
                Row(Modifier.padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Accents.forEachIndexed { i, c ->
                        if (i < 6 || cfg.unlocked) Box(Modifier.size(34.dp).clip(CircleShape).background(c)
                            .then(if (i == cfg.accent) Modifier.border(3.dp, Color.White, CircleShape) else Modifier)
                            .clickable { upd { it.copy(accent = i) } })
                    }
                }
                SliderRow("Glass strength", cfg.glass, 0.04f..0.35f, "${(cfg.glass * 100).toInt()}%") { v -> upd { it.copy(glass = v) } }
                SliderRow("Wallpaper dim", cfg.dim, 0f..0.7f, "${(cfg.dim * 100).toInt()}%") { v -> upd { it.copy(dim = v) } }
                SliderRow("Icon size", cfg.iconSize.toFloat(), 36f..64f, "${cfg.iconSize}dp") { v -> upd { it.copy(iconSize = v.toInt()) } }
                ChoiceRow("Icon shape", listOf("Squircle", "Circle", "Square"), cfg.shape) { i -> upd { it.copy(shape = i) } }
                SwitchRow("Show app names", cfg.labels) { b -> upd { it.copy(labels = b) } }
                SwitchRow("Haptic feedback", cfg.haptic) { b -> upd { it.copy(haptic = b) } }
            }
            Section("Home screen") {
                ChoiceRow("Clock", listOf("Card", "Minimal", "Hidden"), if (!cfg.clock) 2 else cfg.clockStyle.coerceIn(0, 1)) { i ->
                    upd { if (i == 2) it.copy(clock = false) else it.copy(clock = true, clockStyle = i) }
                }
                SwitchRow("24-hour clock", cfg.h24) { b -> upd { it.copy(h24 = b) } }
                SwitchRow("Show date", cfg.date) { b -> upd { it.copy(date = b) } }
                SwitchRow("Show battery", cfg.battery) { b -> upd { it.copy(battery = b) } }
                SwitchRow("Dock", cfg.dock) { b -> upd { it.copy(dock = b) } }
                Text("Custom dock: long-press an app in the drawer, then Add to dock (up to 5).", color = Color.White.copy(.6f), fontSize = 13.sp, modifier = Modifier.padding(bottom = 6.dp))
            }
            Section("App drawer") {
                ChoiceRow("Columns", listOf("3", "4", "5", "6"), (cfg.cols - 3).coerceIn(0, 3)) { i -> upd { it.copy(cols = i + 3) } }
                SwitchRow("List view", cfg.list) { b -> upd { it.copy(list = b) } }
                SwitchRow("Open keyboard with drawer", cfg.kb) { b -> upd { it.copy(kb = b) } }
                SliderRow("Background blur", cfg.blur.toFloat(), 0f..150f, if (cfg.blur == 0) "Off" else "${cfg.blur}") { v -> upd { it.copy(blur = v.toInt()) } }
                Text("Tip: type a sum like 12*8+4 in the search bar.", color = Color.White.copy(.6f), fontSize = 13.sp, modifier = Modifier.padding(bottom = 6.dp))
            }
            Section("Games") {
                SwitchRow("Show Games on home", cfg.games) { b -> upd { it.copy(games = b) } }
                Text("Games are found automatically. To fix one, long-press it in the drawer and choose Add to Games or Remove from Games.",
                    color = Color.White.copy(.6f), fontSize = 13.sp, modifier = Modifier.padding(bottom = 6.dp))
            }
            Section("Gestures") {
                SwitchRow("Swipe down for notifications", cfg.notif) { b -> upd { it.copy(notif = b) } }
                SwitchRow("Double-tap to lock screen", cfg.lockTap) { b -> onLock(b) }
            }
            Section("Hidden apps") {
                val hidden = apps.filter { it.pkg in cfg.hidden }
                if (hidden.isEmpty()) Text("None. Long-press an app in the drawer, then choose Hide app.", color = Color.White.copy(.6f), fontSize = 13.sp, modifier = Modifier.padding(bottom = 6.dp))
                hidden.forEach { a ->
                    Row(Modifier.fillMaxWidth().clickable { upd { it.copy(hidden = it.hidden - a.pkg) } }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Image(a.icon, null, Modifier.size(32.dp))
                        Spacer(Modifier.width(12.dp))
                        Text(cfg.labelOf(a), color = Color.White, modifier = Modifier.weight(1f))
                        Text("Unhide", color = cfg.color, fontSize = 13.sp)
                    }
                }
            }
            if (cfg.lab) Section("Lab 🧪") {
                SwitchRow("Wobble icons", cfg.wobble) { b -> upd { it.copy(wobble = b) } }
                SwitchRow("Party lights", cfg.party) { b -> upd { it.copy(party = b) } }
                Text("You found the secret lab. Tap the version number 7 times again to hide it.", color = Color.White.copy(.6f), fontSize = 13.sp, modifier = Modifier.padding(bottom = 6.dp))
            }
            Section("System") {
                ActionRow("Change wallpaper") { go(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper")) }
                ActionRow("Default home app") { go(Intent(Settings.ACTION_HOME_SETTINGS)) }
                ActionRow("Reset appearance") {
                    upd { Prefs(pins = it.pins, hidden = it.hidden, gAdd = it.gAdd, gRem = it.gRem, dockApps = it.dockApps, renames = it.renames, unlocked = it.unlocked, lab = it.lab, lockTap = it.lockTap) }
                }
                Text("CATOS Launcher v1.2", color = Color.White.copy(.4f), fontSize = 12.sp,
                    modifier = Modifier.clickable { vt++; if (vt >= 7) { vt = 0; onLab() } }.padding(vertical = 8.dp))
            }
        }
    }
}

@Composable
fun ToolTile(icon: String, label: String, on: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val c = LocalCfg.current.color
    Column(
        modifier.press(onClick).glass(RoundedCornerShape(22.dp))
            .then(if (on) Modifier.border(2.dp, c, RoundedCornerShape(22.dp)) else Modifier)
            .padding(vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(icon, fontSize = 26.sp)
        Spacer(Modifier.height(4.dp))
        Text(label, color = Color.White, fontSize = 12.sp)
    }
}

@Composable
fun ToolsSheet(cfg: Prefs, prefs: SharedPreferences, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var note by remember { mutableStateOf(prefs.getString("notes", "") ?: "") }
    var torch by remember { mutableStateOf(false) }
    fun go(i: Intent) { try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {} }
    fun toggleTorch() {
        try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true } ?: return
            torch = !torch
            cm.setTorchMode(id, torch)
        } catch (_: Exception) {
            torch = false
            Toast.makeText(ctx, "Flashlight not available", Toast.LENGTH_SHORT).show()
        }
    }
    Column(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Ink.copy(.86f), Ink.copy(.97f))))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
            .windowInsetsPadding(WindowInsets.systemBars).imePadding().padding(horizontal = 16.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("CATOS", color = cfg.color, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
                Text("Tools", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Light)
            }
            Box(Modifier.size(42.dp).glass(CircleShape).clickable { onClose() }, contentAlignment = Alignment.Center) {
                Text("✕", color = Color.White, fontSize = 16.sp)
            }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ToolTile("🔦", "Torch", torch, Modifier.weight(1f)) { toggleTorch() }
                ToolTile("🔊", "Volume", false, Modifier.weight(1f)) {
                    try { (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager).adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_SAME, AudioManager.FLAG_SHOW_UI) } catch (_: Exception) {}
                }
                ToolTile("📶", "Wi-Fi", false, Modifier.weight(1f)) { go(Intent(Settings.ACTION_WIFI_SETTINGS)) }
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ToolTile("🔵", "Bluetooth", false, Modifier.weight(1f)) { go(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
                ToolTile("🔆", "Display", false, Modifier.weight(1f)) { go(Intent(Settings.ACTION_DISPLAY_SETTINGS)) }
                ToolTile("⚙", "Settings", false, Modifier.weight(1f)) { go(Intent(Settings.ACTION_SETTINGS)) }
            }
            Spacer(Modifier.height(18.dp))
            Text("NOTES", color = cfg.color, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp, modifier = Modifier.padding(start = 6.dp, bottom = 6.dp))
            BasicTextField(
                note, { note = it; prefs.edit().putString("notes", it).apply() },
                textStyle = TextStyle(color = Color.White, fontSize = 16.sp), cursorBrush = SolidColor(cfg.color),
                modifier = Modifier.fillMaxWidth().heightIn(min = 180.dp).glass(RoundedCornerShape(24.dp)).padding(16.dp),
                decorationBox = { inner -> Box { if (note.isEmpty()) Text("Type a quick note…", color = Color.White.copy(.4f)); inner() } }
            )
        }
    }
}
